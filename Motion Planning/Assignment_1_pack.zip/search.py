# -*- coding: utf-8 -*-
"""
Created on Mon Feb  6 11:45:50 2023

@author: Bijo Sebastian
"""


"""
Implement your search algorithms here
"""

import operator

def depthFirstSearch(problem):
  """
  Your search algorithm needs to return a list of actions that reaches the goal
  Strategy: Search the deepest nodes in the search tree first
  """
  "*** YOUR CODE HERE ***"

def breadthFirstSearch(problem):
  """
  Your search algorithm needs to return a list of actions that reaches the goal
  Strategy: Search the shallowest nodes in the search tree first.
  """
  "*** YOUR CODE HERE ***"

def uniformCostSearch(problem):
  """
  Your search algorithm needs to return a list of actions that reaches the goal
  Strategy: Search the node of least total cost first.
  """
  "*** YOUR CODE HERE ***"
  